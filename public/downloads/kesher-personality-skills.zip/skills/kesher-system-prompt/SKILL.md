---
name: kesher-system-prompt