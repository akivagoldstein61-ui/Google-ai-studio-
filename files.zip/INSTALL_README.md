# Kesher Skills Bundle for Claude Code

A drop-in skills pack of 15 Kesher-specific skills that turn Claude Code into a domain-aware co-builder for the Kesher trust-forward dating app.

## What's inside

Fifteen `SKILL.md` packages (some with `references/` subfolders) covering strategy, AI feature modules, integration patterns, UX, and personality systems. The full inventory is in `CONNECTOR_USE_CASES.md`.

## Install

### Option A — Project-scoped (recommended for the Kesher repo)

From the root of your Kesher project:

```bash
# from the unzipped bundle
cp -r kesher-skills-bundle/.claude /path/to/your/kesher-repo/
```

Anyone using Claude Code in that repo automatically gets the skills. Commit `.claude/skills/` to share with the team.

### Option B — User-scoped (available across all your projects)

```bash
mkdir -p ~/.claude/skills
cp -r kesher-skills-bundle/.claude/skills/* ~/.claude/skills/
```

### Option C — Claude.ai / claude.ai project skills

Skills here use the same SKILL.md + frontmatter format used by Claude.ai project skills. You can upload each skill folder individually under your project's Skills tab.

## Verify

In Claude Code, run `/skills` — all 15 should appear. Skills are loaded lazily; Claude only reads a skill's body when its description matches the task at hand.

## Skill list

| Skill | Purpose |
|-------|---------|
| `kesher-system-prompt` | Master orchestrator — run modes, evaluation rubrics, principles |
| `kesher-calm-ux` | Premium calm UX, RTL Hebrew-first design |
| `kesher-ai-feature-modules` | All 11 AI feature modules F01–F11 |
| `kesher-ai-governance` | Feature allocation, model routing, safety rails |
| `kesher-gemini-integration` | Core Gemini patterns — structured outputs, function calling |
| `kesher-low-latency-ai` | Server-side AI proxy, model routing matrix |
| `kesher-high-thinking-routing` | When to enable Gemini high-thinking mode |
| `kesher-explainable-ai` | "Why this match" trust language and templates |
| `kesher-filtering-marketplace` | Hard vs soft filters, Daily Picks vs Explore |
| `kesher-learned-taste` | Implicit/explicit preference learning |
| `kesher-personality-engine` | BFAS personality assessment |
| `kesher-personality-ocean` | OCEAN model + Jewish observance integration |
| `kesher-private-recommendations` | Permissioned sharing, privacy-preserving recs |
| `kesher-maps-date-planner` | Google Maps-grounded date planning |
| `google-ai-studio-app-builder` | Build/deploy via Google AI Studio + Cloud Run |

## Connector use cases

See **`CONNECTOR_USE_CASES.md`** for the matrix mapping each skill to the highest-leverage MCP connector workflows.
