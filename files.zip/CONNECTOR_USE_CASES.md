# Kesher Skills × Connector Apps — Use Case Matrix

This document maps the 15 Kesher skills to the MCP connector apps available in Claude / Claude Code, so you know which pairing to reach for when. Workflows below are **opinionated**: highest leverage first, generic suggestions cut.

Connectors referenced: **Supabase, Vercel, Netlify, Sentry, Figma, Notion, Airtable, Google Drive, Egnyte, Gmail, Google Calendar, Canva, Gamma, Wix, Tavily, Supermetrics, CData Connect AI, Make, DevRev**.

(Play Sheet Music and S&P Global aren't relevant for a dating app and are omitted. Vercel and Netlify are largely interchangeable here — pick one.)

---

## 1 · Headline pairings (the ones to set up first)

These five pairings give you ~80% of the day-to-day leverage.

### A. `kesher-gemini-integration` + `kesher-low-latency-ai` + **Supabase + Sentry + Vercel**
The end-to-end runtime spine. Supabase hosts the AI proxy as Edge Functions plus the policy/feature registry tables; Vercel hosts the client; Sentry catches model errors, timeouts, and JSON-schema violations.
- Claude can scaffold the proxy, deploy edge functions, and wire telemetry in one session.
- Ask: *"Stand up the AI proxy on Supabase Edge Functions following the model routing matrix; send latency + schema-violation events to Sentry."*

### B. `kesher-ai-feature-modules` + **Notion + Airtable**
Notion = the canonical product spec for F01–F11. Airtable = the live feature registry (status, model, latency budget, owner, A/B state) the proxy reads from at runtime via CData Connect AI.
- One Airtable record per AI feature module; Notion holds the long-form doc; CData exposes Airtable to the runtime as SQL.
- Ask: *"Sync the F01–F11 module specs from Notion into an Airtable feature registry, one row per module, with the fields the governance skill expects."*

### C. `kesher-calm-ux` + **Figma + Canva**
Figma for the working design system (RTL, Hebrew-first tokens, calm aesthetic). Canva for produced marketing collateral that has to look on-brand without a designer in the loop.
- Use `Figma:get_design_context` to pull a screen and have Claude write the React + Tailwind that follows the calm-UX rules.
- Use Canva to spin app-store screenshots, social posts, onboarding emails — all keyed to the same brand kit.

### D. `kesher-personality-engine` + `kesher-personality-ocean` + **Supabase + Notion**
BFAS/OCEAN scoring tables and reflection-report templates live in Supabase. Notion holds the assessment item bank and clinical/cultural notes (observance overlays, Hebrew localization decisions). Claude can regenerate the report templates from Notion → Supabase migrations on demand.

### E. `kesher-maps-date-planner` + **Google Calendar + Gmail**
Google Calendar to honor observance windows (Shabbat, fasts, holidays) and check both users' availability before suggesting a slot. Gmail/Calendar to send the actual invite once both parties confirm in-app. The skill provides the fairness/observance logic; the connectors execute.

---

## 2 · Per-skill connector matrix

Top 2–3 connectors per skill with a concrete workflow.

### `kesher-system-prompt` (orchestrator)
| Connector | Use case |
|---|---|
| **Notion** | Run mode outputs (deep research dossiers, evaluation scorecards, architecture docs) write directly into the Kesher Notion space with consistent templates |
| **Tavily** | Deep-research mode citations — Tavily is materially better than raw web search for the multi-source dossier pattern |
| **Google Drive** | Dossier archive / source-of-truth PDFs you've already collected |

### `kesher-calm-ux`
| Connector | Use case |
|---|---|
| **Figma** | Pull frames via `get_design_context`; Claude writes RTL-aware React that respects calm-UX tokens |
| **Canva** | App store screenshots, social, onboarding emails — single brand kit, on-message |
| **Wix / Vercel** | Marketing site (pre-launch waitlist, About, FAQ) using the same calm aesthetic |

### `kesher-ai-feature-modules`
| Connector | Use case |
|---|---|
| **Notion** | Long-form spec per module (F01 Bio Coach … F11 Personality Coach) |
| **Airtable** | Live feature registry — status, model, budget, A/B, kill switch |
| **DevRev** | Per-module bug intake and customer-reported quality issues, tagged by F-id |

### `kesher-ai-governance`
| Connector | Use case |
|---|---|
| **Airtable** | Source of truth for the policy/feature allocation table |
| **Sentry** | Alarm on safety-rail trips (PII leak attempts, toxicity flags, schema violations) — surfaces governance breaches in real time |
| **CData Connect AI** | Lets the runtime proxy query the governance table as SQL without bespoke Airtable plumbing |

### `kesher-gemini-integration`
| Connector | Use case |
|---|---|
| **Supabase** | Edge Functions = the AI proxy; Postgres holds prompt templates, JSON schemas, audit logs |
| **Vercel / Netlify** | Client app hosting; Vercel's preview deployments pair well with prompt-template branches |
| **Sentry** | Captures structured-output failures and tool-call errors with full context |

### `kesher-low-latency-ai`
| Connector | Use case |
|---|---|
| **Supabase Edge Functions** | The proxy itself — close to the user, low cold-start |
| **Sentry Performance** | p50/p95/p99 dashboards per feature; alerts when budgets are blown |
| **Make** | Auto-roll back a feature flag if Sentry's latency budget alert fires |

### `kesher-high-thinking-routing`
| Connector | Use case |
|---|---|
| **Airtable** | Per-feature `thinkingLevel` / `thinkingBudget` config alongside the rest of the registry |
| **Supermetrics** | A/B test results: thinking-on vs thinking-off conversion / report quality |
| **Sentry** | Catch budget overruns and timeout regressions when thinking is enabled |

### `kesher-explainable-ai`
| Connector | Use case |
|---|---|
| **Notion** | Whitelisted-signals catalog and approved phrasing templates ("Why this match" copy bank) |
| **Supabase** | Render-time template store + audit log of which explanation was shown for which match |
| **DevRev** | User feedback on explanations ("this didn't apply to me") — feeds template refinement |

### `kesher-filtering-marketplace`
| Connector | Use case |
|---|---|
| **Supabase** | Hard/soft filter definitions, ranking weights, exposure fairness tables |
| **Supermetrics** | Marketplace health KPIs — match rate by cohort, exposure distribution, reciprocity |
| **Airtable** | Operator-tunable knobs (soft-filter weights, exploration rate) without a deploy |

### `kesher-learned-taste`
| Connector | Use case |
|---|---|
| **Supabase** | Event capture (swipes, dwell, opens) → daily taste-profile rebuild |
| **Sentry** | Detect model drift / anomalous taste-profile shifts |
| **Make** | Trigger a weekly taste-profile refresh job + Slack/email summary to the data team |

### `kesher-personality-engine`
| Connector | Use case |
|---|---|
| **Supabase** | Item bank, scoring, reflection reports stored with the user |
| **Notion** | Item authoring + clinical/translation review workflow |
| **Egnyte** | If you keep psychometric source material under stricter access controls |

### `kesher-personality-ocean`
| Connector | Use case |
|---|---|
| **Supabase** | Compatibility computations live next to user data; minimal cross-service hops |
| **Notion** | Hebrew localization decisions, observance overlays, edge-case adjudication log |
| **CData Connect AI** | Expose OCEAN scores as a SQL view to BI tools without leaking row-level PII |

### `kesher-private-recommendations`
| Connector | Use case |
|---|---|
| **Supabase Row-Level Security** | Enforce permissioned sharing at the database — not just app-layer |
| **Egnyte** | Where third-party privacy/legal docs live; reference them in consent flows |
| **DevRev** | Channel for users to revoke/audit recommendation visibility — legal-grade trail |

### `kesher-maps-date-planner`
| Connector | Use case |
|---|---|
| **Google Calendar** | Read availability + Shabbat/holiday windows; write the confirmed invite |
| **Gmail** | Send the calm, Hebrew-localized invite once both sides confirm in-app |
| **Make** | Orchestrate the whole flow: in-app accept → Calendar holds → Gmail send → reminders |

### `google-ai-studio-app-builder`
| Connector | Use case |
|---|---|
| **Vercel / Netlify** | Deploy the AI Studio prototype's frontend; pair with the 7-day hardening plan |
| **Supabase** | Replace AI Studio's mock backend with real auth + data |
| **Sentry** | Day-one observability when graduating from prototype to MVP |

---

## 3 · Cross-skill workflows worth wiring up

Three orchestrations where multiple skills + multiple connectors compound.

### Workflow 1 — "Ship a new AI feature module end-to-end"
**Skills:** `kesher-system-prompt` → `kesher-ai-feature-modules` → `kesher-ai-governance` → `kesher-gemini-integration` → `kesher-low-latency-ai` → `kesher-explainable-ai`
**Connectors:** Notion (spec) → Airtable (registry) → Figma (design) → Supabase (proxy + tables) → Vercel (deploy) → Sentry (telemetry) → Supermetrics (A/B)

Ask Claude: *"Take the F0X spec from Notion, register it in Airtable, generate the Gemini proxy endpoint on Supabase, wire Sentry alerts at the latency budget, and produce a calm-UX surface from the Figma frame."* The skills coordinate; the connectors execute.

### Workflow 2 — "Plan and execute a date safely"
**Skills:** `kesher-maps-date-planner` + `kesher-private-recommendations` + `kesher-explainable-ai`
**Connectors:** Google Calendar + Gmail + Make + Supabase

Member A and B both opt in → the skill produces 3 venue options that respect both observance calendars and accessibility prefs → Make watches for in-app acceptance → Calendar holds the slot → Gmail sends a Hebrew-first calm invite → the explainable-ai skill provides the "why this venue" copy.

### Workflow 3 — "Continuous safety + governance dashboard"
**Skills:** `kesher-ai-governance` + `kesher-low-latency-ai` + `kesher-learned-taste`
**Connectors:** Sentry + Airtable + Supermetrics + Make + DevRev

Sentry events feed a Make scenario that updates an Airtable governance dashboard. Latency budget breaches auto-flip kill switches. Safety-rail trips create DevRev tickets. Supermetrics overlays user-impact KPIs (matches, retention, complaint rate) so the team sees governance + business in one view.

---

## 4 · Connectors not (yet) worth the wiring effort

| Connector | Why skip for now |
|---|---|
| **Play Sheet Music** | No fit |
| **S&P Global** | No fit (financial data) |
| **Gamma** | Useful for investor decks, but Notion + Canva already cover internal docs and external collateral. Add it later if you find yourself making decks weekly. |

---

## 5 · Recommended setup order

If you're building this stack from scratch, do it in this order:

1. **Supabase + Vercel + Sentry** — runtime spine. Without these three, none of the AI skills have anywhere to live.
2. **Notion + Airtable** — spec and registry. Governance and feature-modules become real once these exist.
3. **Figma + Canva** — design and produced collateral. Needed before any user-facing surface ships.
4. **Google Calendar + Gmail** — unlocks the date-planner skill end-to-end.
5. **Tavily + Supermetrics** — research and analytics; nice-to-have until you have users.
6. **Make + DevRev + CData + Egnyte** — automation and ops layer; add as the team grows.
